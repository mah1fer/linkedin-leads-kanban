// background.js — Service worker for Kanban Bridge extension
const DEFAULT_KANBAN_URL = "https://linkedin-leads-kanban.vercel.app";

function getKanbanUrl() {
    return new Promise((resolve) => {
        chrome.storage.local.get("kanbanUrl", (data) => {
            resolve(data.kanbanUrl || DEFAULT_KANBAN_URL);
        });
    });
}

function buildTabPatterns(appUrl) {
    const patterns = ["*://localhost/*", "*://127.0.0.1/*"];
    try {
        const u = new URL(appUrl);
        patterns.push(`${u.protocol}//${u.host}/*`);
    } catch (_) {}
    return patterns;
}

function sendErrorToApp(requestId, errorMsg) {
    if (!requestId) return;
    getKanbanUrl().then((appUrl) => {
        const patterns = buildTabPatterns(appUrl);
        chrome.tabs.query({ url: patterns }, (tabs) => {
            tabs.forEach(tab => {
                chrome.tabs.sendMessage(tab.id, {
                    type: "KANBAN_EXT_ERROR",
                    id: requestId,
                    error: errorMsg,
                });
            });
        });
    });
}

// ── Timeout watchdog: cancels tasks stuck > 40s ──────────────────────────────
setInterval(() => {
    chrome.storage.local.get("activeTask", (data) => {
        const task = data.activeTask;
        if (!task || !task.startedAt) return;
        const elapsed = Date.now() - task.startedAt;
        if (elapsed > 40000) {
            console.warn("[Kanban SW] Task timed out:", task);
            chrome.storage.local.remove("activeTask");
            chrome.tabs.query({ url: "*://www.linkedin.com/*" }, (tabs) => {
                tabs.forEach(tab => chrome.tabs.remove(tab.id, () => {}));
            });
            sendErrorToApp(task.requestId, "Timeout: certifique-se de estar logado no LinkedIn e tente novamente.");
        }
    });
}, 5000);

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log("[Kanban SW] Message received:", request.action);

    if (request.action === "PUSH_LEAD_TO_KANBAN") {
        getKanbanUrl().then((appUrl) => {
            const patterns = buildTabPatterns(appUrl);
            chrome.tabs.query({ url: patterns }, (tabs) => {
                if (!tabs || tabs.length === 0) {
                    sendResponse({ status: "error", message: "Kanban not open" });
                    return;
                }
                tabs.forEach(tab => {
                    chrome.tabs.sendMessage(tab.id, { type: "KANBAN_EXT_PUSH", lead: request.lead });
                });
                sendResponse({ status: "ok" });
            });
        });
        return true;
    }

    if (request.action === "SEARCH_LINKEDIN") {
        const searchUrl = `https://www.linkedin.com/search/results/people/?keywords=${encodeURIComponent(request.query)}`;
        chrome.storage.local.set({
            activeTask: {
                action: "EXTRACT_SEARCH",
                requestId: request.requestId,
                kanbanTabId: sender.tab?.id,
                startedAt: Date.now(),
            }
        }, () => { chrome.tabs.create({ url: searchUrl, active: true }); });
        sendResponse({ status: "started" });
        return true;
    }

    if (request.action === "IMPORT_BY_LINK") {
        console.log("[Kanban SW] IMPORT_BY_LINK:", request.url);
        chrome.storage.local.set({
            activeTask: {
                action: "STEP1_PROFILE",
                requestId: request.requestId,
                targetUrl: request.url,
                kanbanTabId: sender.tab?.id,
                startedAt: Date.now(),
            }
        }, () => { chrome.tabs.create({ url: request.url, active: true }); });
        sendResponse({ status: "started" });
        return true;
    }

    if (request.action === "LINKEDIN_RESULTS") {
        console.log("[Kanban SW] Forwarding LINKEDIN_RESULTS...");
        getKanbanUrl().then((appUrl) => {
            const patterns = buildTabPatterns(appUrl);
            chrome.tabs.query({ url: patterns }, (tabs) => {
                if (!tabs || tabs.length === 0) return;
                tabs.forEach(tab => {
                    if (request.data) {
                        chrome.tabs.sendMessage(tab.id, {
                            type: "KANBAN_EXT_RESPONSE",
                            id: request.requestId,
                            payload: request.data,
                        });
                    } else {
                        chrome.tabs.sendMessage(tab.id, {
                            type: "KANBAN_EXT_ERROR",
                            id: request.requestId,
                            error: "Perfil não encontrado. Certifique-se de estar logado no LinkedIn.",
                        });
                    }
                });
            });
        });
        chrome.storage.local.remove("activeTask");
        if (sender.tab) chrome.tabs.remove(sender.tab.id, () => {});
    }
});
